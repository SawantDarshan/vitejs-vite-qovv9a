<script setup>
import Home from './pages/Home.vue';
</script>

<template>
  <div>
    <Home />
  </div>
</template>

<style scoped></style>
