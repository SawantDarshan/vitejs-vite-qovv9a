<script setup></script>

<template>
  <div>
    <header>header</header>
    <footer>footer</footer>
  </div>
</template>

<style scoped></style>
